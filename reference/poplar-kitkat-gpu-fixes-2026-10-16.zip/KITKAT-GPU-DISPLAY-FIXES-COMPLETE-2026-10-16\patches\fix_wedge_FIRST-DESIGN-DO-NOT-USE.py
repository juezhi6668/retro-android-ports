#!/usr/bin/env python3
"""
Make a wedged renderer survivable.

Root cause (docs/PROGRESS.md): a synchronous GL call round-trips to glrenderd.
surfaceflinger calls glGetError() from its *compositor* thread (via
GLConsumer::bindTextureImageLocked) on every frame. If glrenderd stops answering
- it wedges inside a driver call, or dies and init restarts it - that thread
blocks in recv() forever, the display never composites again, the framework
watchdog fires and the device sits on a black screen with the backlight on.

Fix: bound the wait, and reconnect instead of failing forever.

  SocketStream   : SO_RCVTIMEO; on timeout or EOF the stream is marked dead and
                   the socket closed, so the caller errors out instead of
                   blocking. (EOF marking it dead is what makes a glrenderd
                   *restart* recoverable too, not just a wedge.)
  HostConnection : get() drops a dead connection, so the next GL call builds a
                   new one. The GL context is gone, so surfaceflinger will give
                   up and restart rather than hang - a blink, not a brick.

No new members and no new virtuals on IOStream/SocketStream: flush()/alloc() are
inline and the prebuilt encoder libraries hard-code the vtable and member
offsets. State lives in a thread-local in SocketStream.cpp, plus two free
functions.
"""
import io
import os
import sys

G = "/root/aosp/device/generic/goldfish/opengl/system/OpenglSystemCommon"
S = "/root/aosp/device/generic/goldfish/opengl/shared/OpenglCodecCommon"


def rd(p):
    with io.open(p, "r", encoding="utf-8", errors="surrogateescape") as f:
        return f.read()


def wr(p, s):
    with io.open(p, "w", encoding="utf-8", errors="surrogateescape") as f:
        f.write(s)


def sub1(s, old, new, what):
    n = s.count(old)
    if n != 1:
        sys.exit("FAIL %s: %d matches" % (what, n))
    return s.replace(old, new, 1)


# ------------------------------------------------------------------ socket header
p = os.path.join(S, "SocketStream.h")
s = rd(p)
DECL = '''#include "IOStream.h"

// POPLAR: a synchronous GL call (glGetError, glCreateProgram, a readback, ...)
// waits for the renderer's reply. If glrenderd wedges, or dies without closing
// the socket cleanly, that wait has to end: for surfaceflinger the waiter is the
// compositor's main thread, and blocking it freezes the display permanently.
// These let the stream give up, and let HostConnection::get() drop the dead
// connection so the next call reconnects.
void glrGuestSetReplyTimeout(int sock);
bool glrGuestStreamDead();
void glrGuestStreamRevive();
'''
s = sub1(s, '#include "IOStream.h"\n', DECL, "SocketStream.h decls")
wr(p, s)

# ------------------------------------------------------------------ socket body
p = os.path.join(S, "SocketStream.cpp")
s = rd(p)
s = sub1(s,
    "#ifndef _WIN32\n#include <netinet/in.h>\n#include <netinet/tcp.h>\n#include <sys/un.h>\n",
    "#ifndef _WIN32\n#include <netinet/in.h>\n#include <netinet/tcp.h>\n#include <sys/un.h>\n"
    "#include <sys/socket.h>\n#include <sys/time.h>\n#include <sys/system_properties.h>\n",
    "SocketStream.cpp includes")

BODY = '''
/*
 * POPLAR: "the renderer stopped answering" is a per-thread fact, matching the
 * per-thread HostConnection and its TLS slot. It is deliberately not a member of
 * SocketStream and not a new virtual: alloc()/flush() are inline, so the
 * prebuilt encoder libraries have them inlined with hard-coded member offsets
 * and vtable slots. Adding either shifts them and breaks those libraries.
 */

// How long to wait for a reply. A legitimate reply is one renderer round-trip:
// milliseconds, or a full-frame readback (~8 MB) at worst. Anything past this is
// a wedged renderer, not a slow one. Overridable for experiments without a
// rebuild:  setprop persist.glr.replytimeout <seconds>
#define GLR_REPLY_TIMEOUT_DEFAULT 20

static __thread bool t_streamDead = false;

bool glrGuestStreamDead() { return t_streamDead; }

void glrGuestStreamRevive()
{
    t_streamDead = false;
    ERR("glr-guest: reconnecting to the renderer\\n");
}

static void glrMarkDead(const char *why)
{
    if (!t_streamDead) {
        t_streamDead = true;
        ERR("glr-guest: giving up on the renderer (%s)\\n", why);
    }
}

void glrGuestSetReplyTimeout(int sock)
{
    if (sock < 0) return;

    int secs = GLR_REPLY_TIMEOUT_DEFAULT;
    char v[PROP_VALUE_MAX];
    if (__system_property_get("persist.glr.replytimeout", v) > 0) {
        int n = atoi(v);
        if (n > 0 && n < 3600) secs = n;
    }

    struct timeval tv;
    tv.tv_sec = secs;
    tv.tv_usec = 0;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
}

'''
s = sub1(s, "SocketStream::SocketStream(size_t bufSize) :", BODY + "SocketStream::SocketStream(size_t bufSize) :",
         "SocketStream.cpp body")

# readFully: bounded wait + mark dead on timeout *and* on EOF
s = sub1(s,
    """        if (stat > 0) {
            res -= stat;
            continue;
        }
        if (stat == 0 || errno != EINTR) { // client shutdown or error
            return NULL;
        }
    }
    return (const unsigned char *)buf;
}""",
    """        if (stat > 0) {
            res -= stat;
            continue;
        }
        if (stat < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            // The renderer is not answering. Do NOT keep waiting: for
            // surfaceflinger this runs on the compositor thread, and blocking
            // here freezes the display for good.
            glrMarkDead("reply timeout");
            return NULL;
        }
        if (stat == 0 || errno != EINTR) { // client shutdown or error
            // Includes EOF: the renderer died or init restarted it. Mark it dead
            // so the next GL call reconnects instead of using a dead socket.
            glrMarkDead(stat == 0 ? "renderer closed the socket" : "socket error");
            return NULL;
        }
    }
    return (const unsigned char *)buf;
}""",
    "readFully")

# writeFully: a dead peer must not leave us silently writing into the void
s = sub1(s,
    """        if (stat < 0) {
            if (errno != EINTR) {
                retval =  stat;
                ERR("%s: failed: %s\\n", __FUNCTION__, strerror(errno));
                break;
            }
        } else {""",
    """        if (stat < 0) {
            if (errno != EINTR) {
                retval =  stat;
                ERR("%s: failed: %s\\n", __FUNCTION__, strerror(errno));
                glrMarkDead("send failed");
                break;
            }
        } else {""",
    "writeFully")
wr(p, s)

# ------------------------------------------------------------------ connect
p = os.path.join(G, "RenderdStream.cpp")
s = rd(p)
s = sub1(s,
    """    m_sock = socket_local_client(kSocketName, ANDROID_SOCKET_NAMESPACE_ABSTRACT, SOCK_STREAM);
    return valid() ? 0 : -1;""",
    """    m_sock = socket_local_client(kSocketName, ANDROID_SOCKET_NAMESPACE_ABSTRACT, SOCK_STREAM);
    if (valid()) {
        // POPLAR: never wait forever for a reply - see SocketStream.cpp
        glrGuestSetReplyTimeout(m_sock);
        return 0;
    }
    return -1;""",
    "RenderdStream connect")
wr(p, s)

# ------------------------------------------------------------------ reconnect
p = os.path.join(G, "HostConnection.cpp")
s = rd(p)
s = sub1(s,
    """        s_ownerPid = me;
    }

    if (tinfo->hostConn == NULL) {""",
    """        s_ownerPid = me;
    }

    // POPLAR: the last call gave up on the renderer (reply timeout, or the
    // socket closed because glrenderd died and init restarted it). Drop the
    // whole connection - stream and encoders - so the next call reconnects
    // rather than failing for the rest of this process's life. For
    // surfaceflinger this is the difference between "GL is gone, restart and
    // recover" and a display frozen forever with the backlight on.
    if (tinfo->hostConn && glrGuestStreamDead()) {
        ALOGE("HostConnection::get() renderer gone, reconnecting\\n");
        delete tinfo->hostConn;
        tinfo->hostConn = NULL;
    }
    glrGuestStreamRevive();

    if (tinfo->hostConn == NULL) {""",
    "HostConnection reconnect")
wr(p, s)

print("OK - guest patched")
