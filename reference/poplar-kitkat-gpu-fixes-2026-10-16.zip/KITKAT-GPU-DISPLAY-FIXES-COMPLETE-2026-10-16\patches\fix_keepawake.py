#!/usr/bin/env python3
"""
Replace the "keepawake" display workaround with a one-shot settings fix.

keepawake.sh existed because the framework's unblank path did not restore the panel
after a screen timeout. That is no longer true (verified: with stay_on_while_plugged_in
0 and a sane timeout, the screen blanks on timeout and wakes on the power key). What
keepawake still did was harmful:

  * every 3 s: `echo 0 > /sys/class/graphics/fb0/blank` and, whenever the backlight read
    0, it wrote 2550 back into it - i.e. if you turned the screen off, the backlight came
    back on a few seconds later, which is the reported bug;
  * once per boot it pinned screen_off_timeout to INT_MAX so the screen never slept.

Replace it with displaytune.sh: wait for the settings provider, then undo the overrides
keepawake left in /data (so an existing install is fixed without a data wipe) and exit.
"""
import io, os, sys

P = "/root/aosp/device/sony/poplar"
RC = P + "/init.poplar.rc"
MK = P + "/full_poplar.mk"
NEW = P + "/displaytune.sh"
OLD = P + "/keepawake.sh"

SH = """#!/system/bin/sh
# Display tuning, once per boot.
#
# This replaces "keepawake", which pinned the panel on as a workaround for the
# framework not restoring it after a screen timeout. That no longer happens, and the
# workaround itself caused the backlight to come back on seconds after the screen was
# switched off. All that is left to do is undo the settings it left behind in /data,
# so an already-installed device gets normal screen blanking without a data wipe.
#
# stay_on_while_plugged_in is also worth resetting: it was left at 3 (stay awake while
# on AC and USB), which keeps the screen on the whole time the device is on adb.
# Users who want that can turn it on again in Settings > Developer options.

n=0
while [ $n -lt 40 ]; do
    settings put global stay_on_while_plugged_in 0 2>/dev/null
    settings put system screen_off_timeout 60000 2>/dev/null
    t=$(settings get system screen_off_timeout 2>/dev/null)
    if [ "$t" = "60000" ]; then
        echo "displaytune: stay_on_while_plugged_in=0 screen_off_timeout=60000" > /dev/kmsg
        exit 0
    fi
    n=$((n + 1))
    sleep 3
done
echo "displaytune: settings provider never came up" > /dev/kmsg
exit 1
"""


def rd(p):
    with io.open(p, "r", encoding="utf-8", errors="surrogateescape") as f:
        return f.read()


def wr(p, s):
    with io.open(p, "w", encoding="utf-8", errors="surrogateescape") as f:
        f.write(s)


def sub1(s, old, new, what):
    if s.count(old) != 1:
        sys.exit("FAIL %s: %d matches" % (what, s.count(old)))
    return s.replace(old, new)


wr(NEW, SH)
os.chmod(NEW, 0o755)

s = rd(MK)
s = sub1(s, "device/sony/poplar/keepawake.sh:root/sbin/keepawake.sh",
            "device/sony/poplar/displaytune.sh:root/sbin/displaytune.sh",
            "mk")
wr(MK, s)

s = rd(RC)
s = sub1(s,
    "# glrenderd owns fb0; keep the panel awake (the framework's unblank path does\n"
    "# not restore it after the screen timeout)\n"
    "on boot\n"
    "    start keepawake\n"
    "\n"
    "service keepawake /system/bin/sh /sbin/keepawake.sh\n"
    "    class core\n"
    "    disabled\n",
    "# Was \"keepawake\": a workaround that pinned the panel on because the framework's\n"
    "# unblank path did not restore it after a screen timeout. That no longer holds, and\n"
    "# the workaround re-lit the backlight seconds after the screen was switched off.\n"
    "# It is now a one-shot that just undoes the settings it left behind, so the screen\n"
    "# blanks on timeout and wakes on the power key like normal.\n"
    "on boot\n"
    "    start displaytune\n"
    "\n"
    "service displaytune /system/bin/sh /sbin/displaytune.sh\n"
    "    class core\n"
    "    disabled\n"
    "    oneshot\n",
    "rc")
wr(RC, s)

try:
    os.remove(OLD)
    print("removed", OLD)
except OSError:
    pass
print("OK")
