#!/usr/bin/env python3
"""Inverse of _fix_inputfreeze.py - restore the stock InputDispatcher.

Run with --reapply to put the patch back afterwards. Exists so the pre-fix
libinputservice.so can be built and kept as a revert artifact (the blob on the
device was overwritten before it was saved).
"""
import io
import os
import subprocess
import sys

D = "/root/aosp/frameworks/base/services/input"


def rd(p):
    with io.open(p, "r", encoding="utf-8", errors="surrogateescape") as f:
        return f.read()


def wr(p, s):
    with io.open(p, "w", encoding="utf-8", errors="surrogateescape") as f:
        f.write(s)


def sub1(s, old, new, what):
    if s.count(old) != 1:
        sys.exit("FAIL %s: %d matches" % (what, s.count(old)))
    return s.replace(old, new, 1)


# ---- header ----
p = os.path.join(D, "InputDispatcher.h")
s = rd(p)
s = sub1(s,
    "    bool mDispatchEnabled;\n    bool mDispatchFrozen;\n"
    "    // POPLAR: monotonic time the current freeze started, 0 when not frozen. Used to\n"
    "    // lift a freeze that is never lifted by the caller (see dispatchOnceInnerLocked).\n"
    "    nsecs_t mDispatchFrozenTime;",
    "    bool mDispatchEnabled;\n    bool mDispatchFrozen;",
    "header member")
wr(p, s)

# ---- implementation ----
p = os.path.join(D, "InputDispatcher.cpp")
s = rd(p)
s = sub1(s,
    "    mDispatchEnabled(false), mDispatchFrozen(false), mDispatchFrozenTime(0),\n"
    "    mInputFilterEnabled(false),",
    "    mDispatchEnabled(false), mDispatchFrozen(false), mInputFilterEnabled(false),",
    "ctor")
s = sub1(s,
    "// POPLAR: how long a frozen dispatch may last before we lift it ourselves.\n"
    "// WindowManagerService freezes dispatch around window transitions; a real\n"
    "// transition is a few hundred milliseconds. If the transition never completes\n"
    "// (e.g. the app that was transitioning died), the frozen branch below returns\n"
    "// without setting nextWakeupTime, so the dispatcher sleeps forever and the\n"
    "// device keeps drawing a UI that accepts no touch at all.\n"
    "#define kMaxDispatchFreezeNanos (10 * 1000000000LL)\n\n",
    "",
    "const")
# the frozen branch: replace the whole patched form with the stock form
start = s.find("    // If dispatching is frozen, do not process timeouts")
end = s.find("    // Optimize latency of app switches.")
if start < 0 or end < 0 or end < start:
    sys.exit("FAIL: cannot locate the frozen branch")
stock = """    // If dispatching is frozen, do not process timeouts or try to deliver any new events.
    if (mDispatchFrozen) {
#if DEBUG_FOCUS
        ALOGD("Dispatch frozen.  Waiting some more.");
#endif
        return;
    }

"""
s = s[:start] + stock + s[end:]
s = sub1(s,
    "            mDispatchFrozen = frozen;\n            mDispatchFrozenTime = frozen ? now() : 0;",
    "            mDispatchFrozen = frozen;",
    "setInputDispatchMode")
wr(p, s)
print("input patch reverted in source")

if "--build" in sys.argv:
    env = dict(os.environ)
    env["JAVA_HOME"] = "/root/toolchains/jdk6"
    env["PATH"] = "/root/toolchains/make381/bin:" + env["JAVA_HOME"] + "/bin:" + env.get("PATH", "")
    cmd = ("source build/envsetup.sh >/dev/null 2>&1; lunch full_poplar-eng >/dev/null 2>&1; "
           "make -j$(nproc) libinputservice 2>&1 | tail -3")
    print(subprocess.run(["bash", "-lc", "cd /root/aosp && " + cmd], env=env,
                         capture_output=True, text=True).stdout)
    src = "/root/aosp/out/target/product/poplar/system/lib/libinputservice.so"
    dst = "/mnt/c/Users/Admin/Desktop/sony xz1/flash/wedgefix/libinputservice.orig.so"
    subprocess.run(["cp", "-f", src, dst], check=False)
    print(subprocess.run(["md5sum", dst], capture_output=True, text=True).stdout)

if "--reapply" in sys.argv:
    print(subprocess.run(["python3",
                          "/mnt/c/Users/Admin/Desktop/sony xz1/_fix_inputfreeze.py"],
                         capture_output=True, text=True).stdout)
