# KITKAT-GPU-DISPLAY-FIXES-COMPLETE-2026-10-16

The complete bundle: the **full document** plus every source file, patch and reference binary
needed to reproduce or port the fixes.

Reference: Xperia XZ1 (`poplar`), MSM8998, Android 4.4.4, 32-bit userspace, Adreno 540.
Intended to port to the **Xperia XZ Premium (`maple`)** or any similar emugl/glrenderd
bring-up.

**Read `GPU-FIX-AND-QUIRKS.md` first** — it explains every change, why it is needed, the symptom
each one fixes, the build-and-flash procedure, and the traps. This README is just the file map.

---

## Layout

```
GPU-FIX-AND-QUIRKS.md      the full document
                           Part A GPU (A1 is the artifact fix) | B display (sleep, brightness,
                           scrim) | C input | D crash evidence | E quirks | F never-do
                           | G verification | H build + flash the boot image
source/                    patched source files (drop-in, or diff against your tree)
patches/                   the exact edit scripts, as run (precise change log)
binaries-poplar-only/      device-built artifacts - REFERENCE ONLY, see the warnings
```

## Applying a fix: source -> artifact -> device path

| fix | source file(s) | builds into | device path | needs |
|---|---|---|---|---|
| fork safety (**the artifact fix**) | `HostConnection.cpp` | `libOpenglSystemCommon.so` | `/system/lib/` | push |
| bounded reply + reconnect + `SIGPIPE` | `SocketStream.cpp/.h`, `RenderdStream.cpp/.h` | `libOpenglSystemCommon.so` | `/system/lib/` | push |
| bound the `glGetError` loops | `GLConsumer.cpp` | `libgui.so` | `/system/lib/` | push |
| frozen input dispatch | `InputDispatcher.cpp/.h` | `libinputservice.so` | `/system/lib/` | push |
| brightness control | `lights.c`, `lights.Android.mk` | `lights.<device>.so` | `/system/lib/hw/` | push |
| sleep / panel power | `displaytune.sh`, `init.rc.reference` | ramdisk | `/sbin/`, `init.<device>.rc` | **boot image** |
| touch post-probe | `init.rc.reference` | ramdisk | `init.<device>.rc` | **boot image** |
| crash evidence keeper | `dump-boot-log.sh` | `/system/bin/` or ramdisk | see Part D | either |
| renderer socket limits, present path | `glrenderd.cpp`, `RenderThread.cpp`, `ReadBuffer.cpp`, `hwchroot.c` | `glrenderd`, `hwchroot` | `/system/glr/`, `/system/glr/root/` | replace + reboot |

Everything under a `root/` prefix in `PRODUCT_COPY_FILES` lives in the **ramdisk**: `init.*.rc`
files and the `/sbin` scripts. Those cannot be delivered with `adb push` — they need
`make bootimage` and a flash. **Part H of the document has the complete procedure.**

## Start with these two

1. **`HostConnection.cpp`** — the fork-safety change. This is what removes the tearing, artifacts
   and out-of-order/skipped frames. Verify with `FRAMING LOST = 0`.
2. **`lights.c`** — without a lights HAL the platform has *no* way to control the backlight, so
   the brightness slider silently does nothing **and** the screen cannot sleep or wake properly.
   It is a missing module, not a broken one. (See B0 and B8.)

Then the rest, in the order the document suggests.

---

## Warnings — please read

* **Do not use `patches/fix_wedge_FIRST-DESIGN-DO-NOT-USE.py`.** It is the first version of the
  reconnect fix, kept only for the record. It frees the connection objects, which is a
  use-after-free; it crashed apps on their next GL call. `fix_reconnect.py` is the corrected
  design and is what `source/` already contains.
* **The binaries are built for `poplar`.** The HALs (`gralloc.poplar.so`, `lights.poplar.so`) are
  device-specific — rebuild them from `source/`. The AOSP-framework libraries (`libgui.so`,
  `libinputservice.so`, `libOpenglSystemCommon.so`) may be usable directly if the target runs the
  same KitKat source, but rebuilding is safer.
* **Do not rebuild the renderer binary on its own.** `glrenderd`'s build regenerates the
  GLESv1/GLESv2/renderControl codec tables, and a mismatch with the guest `*_enc.so` libraries
  already deployed makes the panel come up dim and garbled. Either keep the known-good binary
  (`binaries-poplar-only/glrenderd`, `aff45fc3…`) or rebuild the guest `*_enc.so` libraries from
  the same tree at the same time and deploy them together. `source/glrenderd.cpp` is included for
  reference only.
* **Never add a member to `HostConnection`,** and never move `IOStream`'s members: `alloc()` and
  `flush()` are inline in a header, so every already-built guest library has them inlined with
  hard-coded offsets.
* **Keep a copy of every image and binary you replace**, with its checksum. Both the boot image
  and the libraries here were reverted at least once during bring-up; having the old file on hand
  is what made that a one-liner.

## Checksums of the reference binaries

```
glrenderd                 aff45fc35da87db8802dbdc601544084   known-good, do not rebuild alone
libOpenglSystemCommon.so  0b349652aa5254e8c1cca7688247bf80   fork safety + bounded reply + reconnect
libgui.so                 ce53df3caa873ef32a409a1ce6db1da0   bounded glGetError loops
libinputservice.so        6c5a0588657fe621106e8da2946c96a9   frozen-dispatch thaw
libinputservice.orig.so   76b8fca8c3dd5e47e3bb7fa62df99ce8   stock, for reverting the above
gralloc.poplar.so         d3f5494dc01f2cf7d064da1d5fda64
lights.poplar.so          654641c5350b69d155b7222e347127f2
hwchroot                  484bf2da2d3e39df59279f83a158eba5
```

`patches/check_apk_lib_deps.sh` is a small helper, not part of any fix: point it at an APK's
extracted `lib/` directory plus a list of `/system/lib` and it reports whether everything that app
links against actually exists on the device.
