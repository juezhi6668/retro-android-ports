#!/usr/bin/env python3
"""
Correct the reconnect design: never free the connection, reconnect in place.

The previous version of this fix dropped the whole HostConnection (stream *and*
encoders) when the renderer went silent. That is a use-after-free: the guest EGL
layer caches pointers to the encoders, so after the free the next GL call writes
through a dangling pointer.

Captured proof (Minecraft, main thread):
    #00 libGLESv2_enc.so  GLClientState::setActiveTextureUnit(unsigned int)+17
    #01 libGLESv2_enc.so  GL2Encoder::s_glActiveTexture(void*, unsigned int)+10
    #02 libGLESv2_emulation.so glActiveTexture+18
    #03 libminecraftpe.so mce::TextureOGL::bindTexture(...)+40
    signal 11 SIGSEGV, fault addr 000001a0     <- NULL + offsetof(m_state member)

So instead:
  * SocketStream   : a write on a dead stream is DROPPED and reports success.
    Reporting failure makes IOStream::alloc() return NULL, and the prebuilt
    encoder libraries memcpy straight into it - a second hard crash. Dropping
    leaves GL degraded but the app alive.
  * RenderdStream  : overrides readFully/writeFully (both already virtual, so no
    vtable change) to reconnect the socket in place, rate-limited to one attempt
    per second. The stream object lives on, so every encoder pointer stays valid.
  * HostConnection : the delete-on-dead block is removed.

After an in-place reconnect the guest's client-side GL shadow state no longer
matches the fresh host context, so rendering is wrong until the app recreates its
context. That is a glitch; the alternative was a crash or a hang.
"""
import io
import os
import sys

G = "/root/aosp/device/generic/goldfish/opengl/system/OpenglSystemCommon"
S = "/root/aosp/device/generic/goldfish/opengl/shared/OpenglCodecCommon"


def rd(p):
    with io.open(p, "r", encoding="utf-8", errors="surrogateescape") as f:
        return f.read()


def wr(p, s):
    with io.open(p, "w", encoding="utf-8", errors="surrogateescape") as f:
        f.write(s)


def sub1(s, old, new, what):
    if s.count(old) != 1:
        sys.exit("FAIL %s: %d matches" % (what, s.count(old)))
    return s.replace(old, new, 1)


# ---------------------------------------------------------------- 1. remove the delete
p = os.path.join(G, "HostConnection.cpp")
s = rd(p)
s = sub1(s,
    """    // POPLAR: the last call gave up on the renderer (reply timeout, or the
    // socket closed because glrenderd died and init restarted it). Drop the
    // whole connection - stream and encoders - so the next call reconnects
    // rather than failing for the rest of this process's life. For
    // surfaceflinger this is the difference between "GL is gone, restart and
    // recover" and a display frozen forever with the backlight on.
    if (tinfo->hostConn && glrGuestStreamDead()) {
        ALOGE("HostConnection::get() renderer gone, reconnecting\\n");
        delete tinfo->hostConn;
        tinfo->hostConn = NULL;
    }
    glrGuestStreamRevive();

""",
    """    // POPLAR: do NOT delete the connection here. The EGL layer caches pointers
    // to these encoders, so freeing them is a use-after-free that crashes the
    // app on its next GL call. A dead stream now reconnects itself in place
    // (see RenderdStream::reconnectIfDead).

""",
    "HostConnection delete")
wr(p, s)

# ---------------------------------------------------------------- 2. write on a dead stream
p = os.path.join(S, "SocketStream.cpp")
s = rd(p)
s = sub1(s,
    """int SocketStream::writeFully(const void* buffer, size_t size)
{
    if (!valid()) return -1;""",
    """int SocketStream::writeFully(const void* buffer, size_t size)
{
    if (!valid()) {
        // A dead stream must not report failure: IOStream::alloc() would then
        // return NULL and the (prebuilt) encoder libraries memcpy into it.
        // Dropping the command leaves GL degraded but the process alive.
        return 0;
    }""",
    "writeFully dead stream")
wr(p, s)

# ---------------------------------------------------------------- 3. reconnect in place
p = os.path.join(G, "RenderdStream.h")
s = rd(p)
s = sub1(s,
    """    virtual int connect(unsigned short port);
    int connect() { return connect(0); }""",
    """    virtual int connect(unsigned short port);
    int connect() { return connect(0); }

    // both are already virtual on SocketStream, so overriding them does not
    // change the vtable (`flush()`/`alloc()` are inline and the prebuilt encoder
    // libraries hard-code member offsets; the vtable must not move)
    virtual const unsigned char *readFully(void *buf, size_t len);
    virtual int writeFully(const void *buf, size_t len);""",
    "RenderdStream.h overrides")
s = sub1(s,
    """    // whether this process should use glrenderd at all, decided once. the egl loader in
    // frameworks/native makes the same call so gralloc and egl never disagree
    static bool available();""",
    """    // whether this process should use glrenderd at all, decided once. the egl loader in
    // frameworks/native makes the same call so gralloc and egl never disagree
    static bool available();

private:
    // reconnect the socket in place when the renderer died or went silent. The
    // connection object must survive: the guest EGL layer holds pointers to the
    // encoders built on it, so rebuilding the connection crashes those callers.
    bool reconnectIfDead();""",
    "RenderdStream.h reconnect")
wr(p, s)

p = os.path.join(G, "RenderdStream.cpp")
s = rd(p)
s = sub1(s,
    "#include \"RenderdStream.h\"\n#include <cutils/sockets.h>\n#include <pthread.h>\n#include <unistd.h>",
    "#include \"RenderdStream.h\"\n#include <cutils/sockets.h>\n#include <pthread.h>\n#include <unistd.h>\n#include <sys/time.h>",
    "RenderdStream.cpp includes")
s = sub1(s,
    """static bool s_available;""",
    """// Reconnect the socket in place. The stream object - and therefore every
// encoder built on it - stays alive; only m_sock is replaced. Freeing the
// connection instead (the first version of this fix) left the guest EGL layer
// with dangling encoder pointers and crashed the app in setActiveTextureUnit.
bool RenderdStream::reconnectIfDead()
{
    if (valid()) {
        return true;
    }

    // the caller may be in a hot loop; try at most once a second
    struct timeval now;
    gettimeofday(&now, NULL);
    static __thread long long s_lastTryMs;
    long long nowMs = (long long)now.tv_sec * 1000 + now.tv_usec / 1000;
    if (s_lastTryMs && nowMs - s_lastTryMs < 1000) {
        return false;
    }
    s_lastTryMs = nowMs;

    int fd = socket_local_client(kSocketName, ANDROID_SOCKET_NAMESPACE_ABSTRACT, SOCK_STREAM);
    if (fd < 0) {
        return false;
    }

    m_sock = fd;
    glrGuestSetReplyTimeout(m_sock);
    glrGuestStreamRevive();
    ALOGE("RenderdStream: reconnected to the renderer\\n");
    return true;
}

const unsigned char *RenderdStream::readFully(void *buf, size_t len)
{
    if (!reconnectIfDead()) {
        return NULL;
    }
    return SocketStream::readFully(buf, len);
}

int RenderdStream::writeFully(const void *buf, size_t len)
{
    if (!reconnectIfDead()) {
        // drop it, report success (see SocketStream::writeFully)
        return 0;
    }
    return SocketStream::writeFully(buf, len);
}

static bool s_available;""",
    "RenderdStream.cpp reconnect")
wr(p, s)
print("OK - reconnect reworked (no more use-after-free)")
