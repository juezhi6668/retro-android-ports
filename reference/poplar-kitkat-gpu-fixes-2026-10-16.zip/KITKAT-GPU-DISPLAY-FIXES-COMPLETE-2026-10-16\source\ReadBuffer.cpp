/*
* Copyright (C) 2011 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
#include "ReadBuffer.h"
#include <string.h>
#include <assert.h>
#include <limits.h>
#include "ErrorLog.h"

ReadBuffer::ReadBuffer(IOStream *stream, size_t bufsize)
{
    m_size = bufsize;
    m_stream = stream;
    m_buf = (unsigned char*)malloc(m_size*sizeof(unsigned char));
    m_validData = 0;
    m_readPtr = m_buf;
}

ReadBuffer::~ReadBuffer()
{
    free(m_buf);
}

int ReadBuffer::getData()
{
    if ((m_validData > 0) && (m_readPtr > m_buf)) {
        memmove(m_buf, m_readPtr, m_validData);
    }
    // get fresh data into the buffer;
    size_t len = m_size - m_validData;
    if (len==0) {
        // A packet we cannot consume (bad/duplicated length, or a peer that stops
        // mid-packet) used to make the buffer double without bound until the
        // realloc hit ~2GB and killed the render thread. Cap it, and treat a
        // still-stuck buffer as a broken client so the connection is dropped
        // instead of taking the whole render thread down.
        // 32 MiB is ~4x the largest legal single message (a full 1080x1920
        // RGBA colour-buffer update is 8.3 MB). If we are full at this size
        // the stream is desynced: the decoder needs the whole packetLen
        // before it will dispatch anything (see *_dec.cpp), so a head that
        // declares a length the peer never sends holds the buffer forever.
        if (m_size >= (32u<<20)) {
            ERR("ReadBuffer stuck at %zu bytes with no progress; dropping client\n", m_size);
            return -1;
        }
        size_t new_size = m_size*2;
        if (new_size > (32u<<20)) new_size = (32u<<20);
        unsigned char* new_buf;
        if (new_size < m_size) { // overflow check
            new_size = INT_MAX;
        }

        new_buf = (unsigned char*)realloc(m_buf, new_size);
        if (!new_buf) {
            ERR("Failed to alloc %zu bytes for ReadBuffer\n", new_size);
            return -1;
        }
        m_size = new_size;
        m_buf  = new_buf;
        len    = m_size - m_validData;
    }
    m_readPtr = m_buf;
    if (NULL != m_stream->read(m_buf + m_validData, &len)) {
        m_validData += len;
        return len;
    }
    return -1;
}

void ReadBuffer::consume(size_t amount)
{
    assert(amount <= m_validData);
    m_validData -= amount;
    m_readPtr += amount;
}
