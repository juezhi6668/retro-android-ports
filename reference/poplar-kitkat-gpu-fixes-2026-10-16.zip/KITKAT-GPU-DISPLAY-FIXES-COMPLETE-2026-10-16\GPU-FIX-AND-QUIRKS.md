# KitKat GPU + display fix set — complete, for porting

Reference: Xperia XZ1 (`poplar`), MSM8998, Android 4.4.4 (API 19), 32-bit userspace,
Adreno 540. Expected to apply to the **Xperia XZ Premium (`maple`)** — same SoC generation
and GPU, so the same approach.

Two things are fixed here, both in full:

* **Part A — the GPU fix.** The cause of tearing/artifacts and skipped, reordered frames,
  plus the four follow-ups that make the GPU path reliable. A1 is the actual fix; A2-A6 are
  hardening and performance.
* **Part B — display.** Brightness control needed a `lights` HAL that was missing entirely
  (B8); letting the screen sleep properly needed a boot script that pinned the panel awake to
  be removed (B1-B7).

Parts C–G are supporting fixes, tooling and gotchas, and **Part H is the build-and-flash
procedure** for anything that ships inside the boot image. Paths use `$AOSP` (the AOSP tree) and
`$PORT` (the port's tool tree); `<device>` is the lunch target name.

---

# Part A — the GPU fix (complete)

## A1. Fork safety — **this is the fix for the artifacts**

**File:** `$AOSP/device/generic/goldfish/opengl/system/OpenglSystemCommon/HostConnection.cpp`
**Built into:** `/system/lib/libOpenglSystemCommon.so` — one file, `adb push`, reboot

**Symptom:** screen tearing, artifacts, frames shown out of order or appearing skipped, and
`[glr-rt] FRAMING LOST` / `RESYNC` climbing into the hundreds in the kernel log.

**Cause:** the guest caches its connection to the renderer in a per-thread TLS slot. Every app
is forked from `zygote`, and that slot is inherited across `fork()` — so every app came up
holding **zygote's socket**. Several processes then wrote one stream, interleaved at `send()`
granularity, so a command's header could be split from its payload. Framing was lost for good
and the panel got a mangled mix.

**The fix** — inside `HostConnection::get()`, before the connection is used:

```cpp
    // Fork safety: this thread's TLS (a bionic slot) is inherited across fork(),
    // so an app comes up holding zygote's connection - and zygote's socket.
    static pid_t s_ownerPid = -1;
    pid_t me = getpid();
    if (s_ownerPid != me) {
        if (tinfo->hostConn) {           // created by the process we forked from
            delete tinfo->hostConn;
            tinfo->hostConn = NULL;
        }
        s_ownerPid = me;
    }
```

That is the whole fix.

> The `delete` is correct *here*: this runs on the child's first GL call, before any of that
> child's own code has cached pointers, and processes have separate heaps after `fork()`. It
> is **not** a pattern to reuse when reconnecting after a renderer stall — see A3, where
> deleting crashes apps.

**Build and deploy:**

```sh
cd $AOSP && source build/envsetup.sh && lunch <device>-eng
make -j"$(nproc)" libOpenglSystemCommon

adb root && adb remount
adb push $AOSP/out/target/product/<device>/system/lib/libOpenglSystemCommon.so \
         /system/lib/libOpenglSystemCommon.so
adb shell "chmod 644 /system/lib/libOpenglSystemCommon.so; sync"
adb reboot
```

**Verify:** `FRAMING LOST = 0` and `RESYNC = 0` for a whole boot, and one renderer client per
GL-using process (`[glr-rt] client pid=N` with distinct pids) rather than everything collapsing
onto one. This is the first thing to check for any reordering or tearing symptom.

## A2. Renderer socket limits (silently clamped by the kernel)

**File:** `$PORT/tools/glrenderd/src/glrenderd.cpp`, called from `main()` before
`FrameBuffer::initialize()`.

Linux caps `net.core.rmem_max`/`wmem_max` at ~208 KB by default, which silently clamps an 8 MB
`SO_RCVBUF`; every push from the guest then stalls. Raise both to 16 MB at startup:

```c
#define GLR_SOCK_MAX "16777216"

static void raise_socket_limits(void)
{
    static const char* kPaths[] = {
        "/proc/sys/net/core/rmem_max",
        "/proc/sys/net/core/wmem_max",
    };
    for (unsigned i = 0; i < sizeof(kPaths)/sizeof(kPaths[0]); i++) {
        int fd = open(kPaths[i], O_WRONLY);
        if (fd < 0) continue;
        write(fd, GLR_SOCK_MAX, strlen(GLR_SOCK_MAX));
        close(fd);
    }
    /* read both back and log them, so the log proves it took effect */
}
```

Expect these at boot (they are the proof):

```
glrenderd: /proc/sys/net/core/rmem_max = 16777216
glrenderd: /proc/sys/net/core/wmem_max = 16777216
```

Socket buffers are demand-allocated, so raising the cap costs nothing until data queues.

## A3. A synchronous GL call must never block forever

**Files:**
`$AOSP/device/generic/goldfish/opengl/shared/OpenglCodecCommon/SocketStream.cpp` (+ `.h`)
`$AOSP/device/generic/goldfish/opengl/system/OpenglSystemCommon/RenderdStream.cpp` (+ `.h`)
**Built into:** `/system/lib/libOpenglSystemCommon.so`

Every synchronous GL call (`glGetError`, `glCreateProgram`, any readback) is a socket round
trip. If the renderer is busy or has died, the caller waits forever — and if that caller is the
compositor, the display freezes for good with the backlight on.

**Give the socket a bounded wait.** On the connection:

```c
    /* default 20 s, overridable at runtime so it can be re-tuned without a rebuild
       (reference property name: persist.glr.replytimeout) */
    int secs = 20;
    char v[PROP_VALUE_MAX];
    if (__system_property_get("persist.glr.replytimeout", v) > 0) {
        int n = atoi(v);
        if (n > 0 && n < 3600) secs = n;
    }
    struct timeval tv = { secs, 0 };
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
```

Pick the default generously. The worst *legitimate* reply is a full-frame readback (a few
milliseconds) and system_server's watchdog fires at 60 s, so 20 s sits far from both. Keep it in
a property and it can be changed on a running device without a rebuild; `0` or a non-numeric
value falls back to the default.

**Treat timeout *and* EOF as a dead connection**, close it, and **reconnect in place**:

```c
    /* in readFully() */
    if (stat < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
        markDead("reply timeout");
        return NULL;
    }
    if (stat == 0 || errno != EINTR) {   /* stat == 0 is EOF: renderer died or restarted */
        markDead("renderer closed the socket");
        return NULL;
    }
```

```c
    /* in the renderd stream: reconnect the socket, keep the object */
    bool RenderdStream::reconnectIfDead()
    {
        if (valid()) return true;

        /* rate limit: the caller may be in a hot loop */
        static __thread long long lastTryMs;
        long long nowMs = now();
        if (lastTryMs && nowMs - lastTryMs < 1000) return false;
        lastTryMs = nowMs;

        int fd = socket_local_client(kSocketName, ANDROID_SOCKET_NAMESPACE_ABSTRACT, SOCK_STREAM);
        if (fd < 0) return false;
        m_sock = fd;
        setReplyTimeout(m_sock);
        return true;
    }

    const unsigned char *RenderdStream::readFully(void *buf, size_t len)
    {
        if (!reconnectIfDead()) return NULL;
        return SocketStream::readFully(buf, len);
    }
```

**Two traps that cost real debugging time:**

1. **Never free or replace the `HostConnection` on reconnect.** The guest EGL layer caches
   pointers to the encoders built on it. Freeing them is a use-after-free: the next GL call
   crashes (we saw `SIGSEGV` in `GLClientState::setActiveTextureUnit`, fault address `0x1a0` =
   NULL + member offset, with the backtrace running through `libminecraftpe`). Reconnect the
   socket and leave the object alone.
2. **A write on a dead stream must report success, not failure.** Reporting failure makes
   `IOStream::alloc()` return NULL, and the prebuilt encoder libraries `memcpy` straight into
   it — a second hard crash. Drop the command instead:

```c
    int SocketStream::writeFully(const void* buffer, size_t size)
    {
        if (!valid()) return 0;      /* was: return -1 - that NULLs alloc() and crashes */
        ...
    }
```

Both `readFully`/`writeFully` are already `virtual` on the base class, so overriding them in
the derived stream does **not** move the vtable.

**3. And in the same function, never let a closed socket raise `SIGPIPE`.** The original code
sent with `::send(m_sock, ..., 0)`. When the renderer closed the socket, `send()` raised
`SIGPIPE` and **killed the caller** — in practice `surfaceflinger`, whose death invalidates every
surface and leaves a black scrim covering the panel. Send with `MSG_NOSIGNAL` so a closed socket
is an ordinary `-1`/`EPIPE` you can handle:

```c
    ssize_t stat = ::send(m_sock, buf, len, MSG_NOSIGNAL);
```

This one is easy to overlook and looks like an unrelated crash in the logs: the tombstone reads
`signal 13 (SIGPIPE)` with a backtrace running `SocketStream::writeFully` →
`SocketStream::commitBuffer` → `glGetError_enc` → `GLConsumer::bindTextureImageLocked` →
`libsurfaceflinger`.

**Consequence to accept:** after an in-place reconnect the guest's client-side GL shadow state
no longer matches the fresh host context, so rendering is wrong until the app recreates its
context. That is a glitch, chosen over a crash or a permanent freeze.

## A4. Framework: bound the `glGetError()` clearing loops

**File:** `$AOSP/frameworks/native/libs/gui/GLConsumer.cpp`
**Built into:** `/system/lib/libgui.so`

`GLConsumer::bindTextureImageLocked()` runs for **every buffer a SurfaceTexture-backed app
hands to the compositor** — i.e. every game frame. It begins with:

```cpp
    GLint error;
    while ((error = glGetError()) != GL_NO_ERROR) {      // UNBOUNDED
        ST_LOGW("bindTextureImage: clearing GL error: %#04x", error);
    }
```

Locally that is a cheap idiom. Here **every iteration is a blocking round trip on the
compositor thread**, so a busy renderer parks the display with no way back. Replace with a
bounded loop (8 is ample), and do the same for the identical loop in
`bindUnslottedBufferLocked()`:

```cpp
    GLint error;
    for (int i = 0; i < 8 && (error = glGetError()) != GL_NO_ERROR; i++) {
        ST_LOGW("bindTextureImage: clearing GL error: %#04x", error);
    }
```

Symptom it removes: UI frozen permanently while a game runs, backlight still on.

## A5. Renderer: cap the receive buffer, and clean up dropped clients

**File:** `$AOSP/sdk/emulator/opengl/host/libs/libOpenglRender/ReadBuffer.cpp` and
`.../RenderThread.cpp`

Bound the read buffer (32 MiB is enough) and shut the stream down when a client goes away —
otherwise a dropped client parks in the socket allocator indefinitely. The renderer's framing
sanity limit (`GLR_MAX_MSG`) is 24 MiB and the stream buffer 8 MiB, so **any single GL command
larger than ~24 MiB breaks framing and drops that client** (keep an eye on large texture or
buffer uploads).

## A6. Optional: drop the staging copy in the present path

**Files:** `$PORT/tools/glrenderd/src/glrenderd.cpp` +
`$AOSP/sdk/emulator/opengl/host/libs/libOpenglRender/FrameBuffer.cpp`

The renderer originally read the frame back and then copied it into a staging buffer before
panning — an extra full-frame (~8 MB) copy. Letting the readback land directly in a presenter
slot removes it (`FrameBuffer::getFB()->setPostReadback(present_acquire, &s_pres);` installed
after `FrameBuffer::initialize()`); measured 6.9 ms → 4.2 ms per frame.

**Do not** make the readback write straight into the panel page. Tried and reverted: it
couples the render thread to the vblank-locked pan while holding the frame buffer lock (hung
the boot) and races the pane's back buffer (garbled frames).

## A7. Where the GPU fix lands on the device

| source | built artifact | device path |
|---|---|---|
| `.../OpenglSystemCommon/HostConnection.cpp` | `libOpenglSystemCommon.so` | `/system/lib/libOpenglSystemCommon.so` |
| `.../OpenglCodecCommon/SocketStream.cpp` | `libOpenglSystemCommon.so` | same |
| `.../OpenglSystemCommon/RenderdStream.cpp` | `libOpenglSystemCommon.so` | same |
| `frameworks/native/libs/gui/GLConsumer.cpp` | `libgui.so` | `/system/lib/libgui.so` |
| `.../system/gralloc/gralloc.cpp` | `gralloc.<device>.so` | `/system/lib/hw/gralloc.<device>.so` |
| `$PORT/tools/glrenderd/src/glrenderd.cpp` | `glrenderd`, `hwchroot` | `/system/glr/hwchroot`, `/system/glr/root/glrenderd` |
| host `libOpenglRender/*` | (same `glrenderd`) | same |

All libraries are loaded per process, and the renderer is started by init, so **everything
takes effect after a reboot**.

---

# Part B — display: brightness control, sleeping properly, and the keyguard scrim (complete)

## B0. Why brightness and sleep are the same problem

Worth understanding first, because it changes what "screen off" even means on this port:

* **The framework never blanks the panel.** The renderer owns `fb0` and keeps presenting to it
  continuously. There is no framebuffer blank to toggle, and fighting the renderer over `fb0`
  wedges the display controller (the one-flipper quirk in Part E).
* **So "screen off" means the backlight goes to 0**, and "screen on" means it comes back — both
  driven by the framework **through the lights HAL**.
* **No lights HAL therefore means no sleep and no wake.** That one missing module is why an
  early bring-up ended up with a script forcing the backlight from a timer (B1) — and why waking
  the device afterwards was unreliable: the framework had no working way to put the backlight
  back.
* **Fix B8 first, then B1–B7.** With the HAL in place the framework can genuinely drive the
  backlight both ways, so removing the timer workaround is safe — and that is what makes
  "power off stays off, power on restores it" work.

## B1. What was wrong

The screen turned off and then lit back up a few seconds later; the phone behaved as if it
never slept. Two causes, both leftovers:

**1. A boot-time hack script.** An init service started a script that looped every 3 seconds.
On the reference tree it is `keepawake.sh` with a service of the same name — find it and remove
both the script and the `start` line, whatever it is called on yours:

```sh
while true; do
    echo 0 > /sys/class/graphics/fb0/blank          # force the panel unblanked
    b=$(cat /sys/class/leds/lcd-backlight/brightness)
    if [ -z "$b" ] || [ "$b" = "0" ]; then
        echo 2550 > /sys/class/leds/lcd-backlight/brightness   # put the light back on
    fi
    sleep 3
done
```

Turning the screen off makes the framework set brightness 0 — and keepalive wrote it straight
back within 3 seconds. It also pinned `screen_off_timeout` to `2147483647` once per boot, so
the screen never slept on its own.

It existed because the framework's unblank path had been failing to restore the panel after a
screen timeout. **Check whether that is still true on your device before removing it** (B6) —
if it is, fix the unblank path instead of pinning the panel on.

**2. `stay_on_while_plugged_in = 3`** (stay awake on AC + USB). With the device on adb, the
framework is *configured* to keep the screen awake.

## B2. Replace the script with a one-shot

Delete the old script and add this in its place (the same directory in the device tree):

```sh
#!/system/bin/sh
# Display tuning, once per boot.
#
# Replaces a workaround that pinned the panel on because the framework did not
# restore it after a screen timeout. All that is left to do is undo the settings
# that workaround left behind in /data, so an existing install gets normal screen
# blanking without a data wipe.
#
# stay_on_while_plugged_in is also worth resetting: it was left at 3 (stay awake
# while on AC and USB), which keeps the screen on the whole time it is on adb.

n=0
while [ $n -lt 40 ]; do
    settings put global stay_on_while_plugged_in 0 2>/dev/null
    settings put system screen_off_timeout 60000 2>/dev/null
    t=$(settings get system screen_off_timeout 2>/dev/null)
    if [ "$t" = "60000" ]; then
        echo "displaytune: stay_on_while_plugged_in=0 screen_off_timeout=60000" > /dev/kmsg
        exit 0
    fi
    n=$((n + 1))
    sleep 3
done
echo "displaytune: settings provider never came up" > /dev/kmsg
exit 1
```

## B3. Change the init service to a one-shot

In `$AOSP/device/<vendor>/<device>/init.<device>.rc`, **delete** the old
`on boot / start <old_service>` line and its `service` block, and put this in their place:

```
# --- display tuning ------------------------------------------------------------
# Was a workaround that pinned the panel on, because the framework's unblank path
# did not restore it after a screen timeout. That no longer holds, and the
# workaround re-lit the backlight seconds after the screen went off. It is now a
# one-shot that just undoes the settings it left behind.
on boot
    start displaytune

service displaytune /system/bin/sh /sbin/displaytune.sh
    class core
    disabled
    oneshot
```

`oneshot` matters: a looping script would be restarted by init forever.

## B4. Point the build at the new file

In `$AOSP/device/<vendor>/<device>/<device>.mk`:

```
    device/<vendor>/<device>/displaytune.sh:root/sbin/displaytune.sh \
```

Note the `root/sbin/` prefix — that puts it in the **ramdisk**, not `/system`. So this change
(and the `.rc` change) requires rebuilding the boot image.

## B5. Deploy

Both pieces live in the **ramdisk**, so they ship in the boot image — **Part H has the complete
build-and-flash procedure** (toolchain, kernel, build, ramdisk check, flashing). In short:

```sh
make -j"$(nproc)" bootimage
# then: fastboot flash boot out/target/product/<device>/boot.img
```

`/sbin` and `init.<device>.rc` are both in the ramdisk. Verify the ramdisk actually contains the
changes before flashing:

```sh
grep -n 'displaytune' $AOSP/out/target/product/<device>/root/init.<device>.rc
ls -l $AOSP/out/target/product/<device>/root/sbin/displaytune.sh
```

Also remove the stale script from the staging directory if it is still there — the build does
not delete removed files from `out/` on its own.

## B6. Test it live first (no boot image needed)

Before rebuilding anything, prove on a booted device that the old workaround is no longer
needed:

```sh
adb root
adb shell "stop <old_service_name>"          # kill the keep-awake loop
adb shell "settings put global stay_on_while_plugged_in 0"
adb shell "settings put system screen_off_timeout 15000"
```

Then, without touching the device:
* press power → the backlight goes to **0 and stays 0** for at least 15 s;
* leave it idle → it ramps down and reaches 0 on its own;
* press power again → backlight comes back.

If the screen **does not come back** after a timeout, the original problem still exists on your
device — fix the unblank path rather than shipping B2.

## B7. Verify after flashing

```
power off  -> backlight 0 and stays 0
idle       -> ramps to 0 (screen_off_timeout)
power on   -> backlight restored
displaytune: stay_on_while_plugged_in=0 screen_off_timeout=60000   <- in the kernel log
```

The background behind this fix is worth stating plainly: **only the framework and the renderer
should ever touch the panel.** Any periodic script that writes to
`/sys/class/graphics/fb0/blank` or the backlight brightness will fight the framework's power
state and produce exactly this "it never sleeps" bug.

---

## B8. Brightness control needs a `lights` HAL — it was missing entirely

**Files:** `$AOSP/device/<vendor>/<device>/lights/lights.c` and `lights/Android.mk`
**Built into:** `/system/lib/hw/lights.<device>.so`

**Symptom:** the brightness slider does nothing, and the framework has no way to drive the
backlight at all. On the reference device `/system/lib/hw` shipped `gralloc.*` but **no
`lights.*` module**, so `hw_get_module(LIGHTS_HARDWARE_MODULE_ID)` found nothing and every
brightness request was silently dropped.

**Fix:** a small lights HAL that takes the framework's 0-255 request, scales it onto the
panel's own `max_brightness`, and writes the sysfs node.

```c
/* lights HAL for Sony Xperia XZ1 (poplar) - KitKat.
 * Backlight via /sys/class/leds/lcd-backlight/brightness. */
#define LOG_TAG "lights.poplar"

#include <cutils/log.h>
#include <cutils/properties.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <hardware/lights.h>

static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;

static const char *const LCD_BRIGHTNESS    = "/sys/class/leds/lcd-backlight/brightness";
static const char *const LCD_MAX           = "/sys/class/leds/lcd-backlight/max_brightness";

static int read_int(const char *path)
{
    int fd = open(path, O_RDONLY);
    char buf[16];
    int n;
    if (fd < 0) return -1;
    n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return -1;
    buf[n] = '\0';
    return atoi(buf);
}

static int write_int(const char *path, int value)
{
    int fd = open(path, O_WRONLY);
    char buf[16];
    int n;
    if (fd < 0) return -errno;
    n = snprintf(buf, sizeof(buf), "%d\n", value);
    if (write(fd, buf, n) != n) { close(fd); return -EIO; }
    close(fd);
    return 0;
}

/* the framework hands us an RGB light state; weight it to a single 0-255 level */
static int rgb_to_brightness(const struct light_state_t *state)
{
    unsigned int color = state->color & 0x00ffffff;
    return ((77 * ((color >> 16) & 0xff)) +
            (150 * ((color >> 8) & 0xff)) +
            (29  * (color & 0xff))) >> 8;
}

static int set_light_backlight(struct light_device_t *dev,
                               const struct light_state_t *state)
{
    int v = rgb_to_brightness(state);
    int max = read_int(LCD_MAX);
    int scaled;
    (void)dev;

    if (max <= 0) max = 4095;                 /* do not hard-code it: read max_brightness */
    scaled = (v * max) / 255;
    if (v > 0 && scaled < 1) scaled = 1;      /* lowest slider step must not mean "off" */

    pthread_mutex_lock(&g_lock);
    write_int(LCD_BRIGHTNESS, scaled);
    pthread_mutex_unlock(&g_lock);
    return 0;
}

static int set_light_buttons(struct light_device_t *dev,
                             const struct light_state_t *state)
{
    (void)dev; (void)state;                   /* no button backlight on this device */
    return 0;
}

static int close_lights(struct light_device_t *dev)
{
    if (dev) free(dev);
    return 0;
}

static int open_lights(const struct hw_module_t *module, const char *name,
                       struct hw_device_t **device)
{
    int (*set_light)(struct light_device_t *, const struct light_state_t *);
    struct light_device_t *dev;

    if (!strcmp(LIGHT_ID_BACKLIGHT, name))
        set_light = set_light_backlight;
    else if (!strcmp(LIGHT_ID_BUTTONS, name))
        set_light = set_light_buttons;
    else
        return -EINVAL;

    dev = malloc(sizeof(*dev));
    if (!dev) return -ENOMEM;
    memset(dev, 0, sizeof(*dev));
    dev->common.tag = HARDWARE_DEVICE_TAG;
    dev->common.version = 0;
    dev->common.module = (struct hw_module_t *)module;
    dev->common.close = (int (*)(struct hw_device_t *))close_lights;
    dev->set_light = set_light;
    *device = &dev->common;
    return 0;
}

static struct hw_module_methods_t lights_module_methods = {
    .open = open_lights,
};

struct hw_module_t HAL_MODULE_INFO_SYM = {
    .tag = HARDWARE_MODULE_TAG,
    .version_major = 1,
    .version_minor = 0,
    .id = LIGHTS_HARDWARE_MODULE_ID,
    .name = "poplar lights",
    .author = "kitkat-poplar",
    .methods = &lights_module_methods,
};
```

`lights/Android.mk`:

```make
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE_PATH := $(TARGET_OUT_SHARED_LIBRARIES)/hw
LOCAL_SRC_FILES := lights.c
LOCAL_SHARED_LIBRARIES := liblog libcutils
LOCAL_MODULE := lights.<device>
LOCAL_MODULE_TAGS := optional
include $(BUILD_SHARED_LIBRARY)
```

Wire it into the product:

* add `lights.<device>` to `PRODUCT_PACKAGES` in `$AOSP/device/<vendor>/<device>/<device>.mk`;
* set **`TARGET_PROVIDES_LIBLIGHT := true`** — without it the build also pulls in the AOSP
  default lights module and the two fight over `lights.default`;
* do **not** `include` the lights `Android.mk` from `AndroidBoard.mk` as well. The build already
  picks up `device/**/Android.mk`, and a duplicate include fails with "module already defined".

**Build and deploy:**

```sh
cd $AOSP && source build/envsetup.sh && lunch <device>-eng
make -j"$(nproc)" lights.<device>

adb root && adb remount
adb push $AOSP/out/target/product/<device>/system/lib/hw/lights.<device>.so \
         /system/lib/hw/lights.<device>.so
adb shell "chmod 644 /system/lib/hw/lights.<device>.so; sync"
adb reboot        # the framework loads the HAL at boot
```

The HAL can be live-pushed and takes effect once the framework reloads it, but a reboot is the
reliable way.

**Verify:** the brightness slider visibly changes the panel,
`/sys/class/leds/lcd-backlight/brightness` follows it, and turning the screen off drives it to 0.

---

## B9. A black full-screen "scrim" that also eats every touch

**File:** the keyguard delegate inside **`android.policy.jar`** — a dex jar, *not*
`framework.jar`. (Patching the wrong jar is an easy and expensive mistake; `android.policy.jar`
is where `PhoneWindowManager` / `KeyguardServiceDelegate` live.)

**Symptom:** the screen fades to full black, the phone looks hung, and touch does nothing — but
the framework is alive and the UI may still be animating underneath. This is easy to mistake for
the GPU freeze in Part A.

**Cause:** when the keyguard window goes away (a crash, or the keyguard degrading under heavy
latency), `PhoneWindowManager` parks a full-screen black `KeyguardScrim` window as a placeholder.
It **takes focus**, so it swallows input.

**Diagnose:**

```sh
dumpsys window | grep mCurrentFocus
```

If that reports `KeyguardScrim` rather than your launcher, this is it.

**Fix:** patch `KeyguardServiceDelegate` in `android.policy.jar`:

* `showScrim()` → make it a no-op;
* give the scrim window `FLAG_NOT_TOUCHABLE | FLAG_NOT_FOCUSABLE`.

Rebuild `android.policy.jar`, push it **together with its `.odex`** (KitKat boots from the
pre-optimised odex), and reboot.

**Verify:** `dumpsys window | grep mCurrentFocus` now reports the launcher, and the scrim window
still exists but no longer takes focus.

Worth knowing if you hit this while the GPU path is still slow: the scrim appears because the
keyguard is degrading, so shortening the render time (e.g. driving the renderer at 540x960 — a 4×
smaller readback, roughly 2 ms) shrinks the window in which it can appear. That is a mitigation;
the patch above is the fix.

---

# Part C — input: make touch work, and keep it working

## C1. Touch does nothing *at all*: the controller never finished probing

**File:** `$AOSP/device/<vendor>/<device>/init.<device>.rc` (a `write` in an init action)

**Symptom:** the panel and UI come up fine, but there is **no touch at all** — not flaky touch,
nothing.

**Cause:** the touch controller driver does not complete its post-probe until it is told to.
Until then it emits no input events, even though the input device is registered and does appear
in `/proc/bus/input/devices` — so the usual "is the device there?" check passes and misleads you.

**Fix:** write `1` to its `post_probe_start` node from init:

```
on post-fs-data
    # the touch controller doesn't finish probing (no touch events) until this
    write /sys/devices/virtual/input/<touchdriver>/post_probe_start 1
```

On the reference device the node is `/sys/devices/virtual/input/clearpad/post_probe_start`;
check the directory name under `/sys/devices/virtual/input/` on the target.

**Verify:** touches produce events — `dumpsys input` should list a `touchScreen` device and show
a non-empty `RecentQueue` while you touch the panel.

> Related, and harmless: at boot the driver may log `fw request failed (rc=-11)` followed by
> `fw flash failed but continue init`. If the firmware file is not where the driver was told to
> look, it carries on with whatever is already on the controller and touch still works. Do not
> chase that unless touch is genuinely broken.

## C2. Input dispatch can freeze permanently

**Files:** `$AOSP/frameworks/base/services/input/InputDispatcher.cpp` (+ `.h`)
**Built into:** `/system/lib/libinputservice.so` — note: **not** `libandroid_servers.so`,
which is only the JNI side

**Symptom:** the phone is alive and the UI keeps animating, but **no touch and no power
button**.

WindowManager freezes input dispatch around window transitions. If the transition never
completes — common when the app being transitioned dies — nothing thaws it, because the frozen
branch of `dispatchOnceInnerLocked()` returns **without setting `*nextWakeupTime`**, so the
dispatcher sleeps on an infinite timeout.

**Diagnose:**

```sh
dumpsys input | grep -E 'DispatchEnabled|DispatchFrozen|InboundQueue'
```

`DispatchFrozen: 1` with a growing `InboundQueue` is this bug. (Note `DispatchEnabled: 0` with
`DispatchFrozen: 0` is just a sleeping screen — normal.)

**Fix:** track when the freeze started, and lift it yourself once it is clearly abandoned:

```cpp
    if (mDispatchFrozen) {
        if (mDispatchFrozenTime && currentTime - mDispatchFrozenTime > kMaxDispatchFreezeNanos) {
            /* log it, then: */
            mDispatchFrozen = false;
            mDispatchFrozenTime = 0;
            resetANRTimeoutsLocked();
            mLooper->wake();
        } else {
            /* arm a wakeup at the deadline, or this branch parks forever */
            if (mDispatchFrozenTime) {
                nsecs_t deadline = mDispatchFrozenTime + kMaxDispatchFreezeNanos;
                if (deadline < *nextWakeupTime) *nextWakeupTime = deadline;
            }
            return;
        }
    }
```

with `#define kMaxDispatchFreezeNanos (10 * 1000000000LL)` (a real transition is ~300 ms), and
`mDispatchFrozenTime = frozen ? now() : 0;` wherever the freeze flag is set.

---

# Part D — keep crash evidence before it rotates away

`/data/tombstones` keeps only the last 10 files, and unrelated churn rotates real crashes out —
that is how the first renderer crash was lost, and how a bug of our own survived a whole
debugging session. A periodic script that copies every **distinct** tombstone (keyed by its
pid) to a keep-forever directory, plus rotating `dmesg` snapshots a few files deep, is what made
diagnosis possible afterwards:

```sh
KEEP=/data/misc/keep
mkdir -p $KEEP

# rotating dmesg, ~10 min deep; a single file is overwritten while the system dies
i=$((n % 24)); dmesg > /data/misc/kmsg-$i.txt 2>/dev/null

# one copy per distinct crash, whatever the 10-file rotation does
for f in /data/tombstones/*; do
    [ -e "$f" ] || continue
    pid=$(busybox grep -m1 '^pid:' "$f" | busybox awk -F'[ ,]+' '{print $2}')
    [ -z "$pid" ] && continue
    [ -e "$KEEP/tomb.$pid" ] || busybox cp "$f" "$KEEP/tomb.$pid"
done
```

Also record each renderer start (`/proc/<pid>/stat` field 22) each pass — that is how a
renderer restart becomes visible from userspace.

### Tools that are worth knowing

Every conclusion in the document came from one of these:

* **Kernel stacks of a live process:** `debuggerd -b <pid>` prints all of its threads' native
  backtraces. This is what produced the `surfaceflinger` stack in A4 — and it works *while* the
  process is stuck, which is the point.
* **Userspace state:** `dumpsys input` (dispatch and touch devices), `dumpsys window | grep
  mCurrentFocus` (who owns focus — catches the scrim in B9), `dumpsys SurfaceFlinger`.
* **The renderer's own diagnostics**, in the kernel log: a per-connection ring of the last
  commands, `FRAMING LOST` / `RESYNC` / `NOPAYLOAD` reports, and — when a client's framing
  breaks — a rolling copy of that connection's raw bytes to `/dev/glr-stream-<pid>.bin`. That
  stream dump is what proved the interleaving in A1: one file, several processes' commands
  woven together.
* **A deliberate dump:** `kill -6 <pid>` writes `/data/tombstones/tombstone_*`; `kill -3 <pid>`
  dumps userspace threads. Useful when you want evidence on demand rather than after a failure.
* **The kernel's own view:** `echo t > /proc/sysrq-trigger` (all tasks) and `echo w` (blocked
  tasks only) list every task with its kernel stack. That is how "this is not a kernel
  deadlock" was established, rather than assumed.
* **Frame timing:** the renderer's per-frame line — `readback` / `copy` / `flip` in ms — tells
  you which stage you are actually paying for.

---

# Part E — environment quirks

* **`logcat` is unusable** if the kernel lacks `CONFIG_ANDROID_LOGGER`. The only log is
  `dmesg` / `/dev/kmsg`; point the renderer's stderr at `/dev/kmsg` and everything shows up
  there. Log to a file under `/data` when a process cannot write `/dev/kmsg`.
* **Toolbox is minimal** — no `head`, `tail`, `wc`, `sort`, `pkill`, `pidof`. Push a busybox and
  use it. Beware: piping toolbox `grep` into a missing command kills it with `SIGPIPE`, which on
  an eng build writes a tombstone — that is how a real crash got rotated away once.
* **The device clock may read 1972**, so dropbox timestamps are useless for ordering. Use
  `/proc/<pid>/stat` field 22 (start ticks) instead.
* **One flipper only.** The renderer owns `fb0`; if it and the framework both pan the
  framebuffer, the display controller's overlay start wedges (`EBUSY`) and the panel freezes on
  the boot splash.
* **`FBIOPAN_DISPLAY` with `FB_ACTIVATE_VBL`, not `FBIOPUT_VSCREENINFO`** — the latter can take
  the DRM `set_par` path and redo the whole mode. Expect vblank waits to show as "flip" time.
* **Panel geometry:** the panel may be larger than what you render. A 4K panel driven at
  1080x1920 gets whole-multiple pixel repetition. Expect `stride` to be row size in pixels, not
  width — e.g. `panel 1080x1920 stride 4352 flips 1 swap 0`.
* **The readback is the floor.** Every frame is read back (GPU→CPU, ~8 MB) and every GL call is
  a socket round trip; ~9-10 ms per frame readback and a ~35-40 fps ceiling on this class of
  device. Beating it means rendering into the panel's memory directly (an EGL/gralloc surface
  over `fb0`) — a re-architecture, not a tweak.
* **Reach the renderer over an abstract unix socket** (e.g. `@glrenderd`), start the renderer
  before the framework, and patch the EGL loader to wait a few seconds for it so EGL and gralloc
  never disagree about whether the renderer exists.
* **32-bit only:** `ro.product.cpu.abi=armeabi-v7a`, `abi2=armeabi`. Keep the guest encoders,
  the chroot and the renderer all 32-bit, or the codec tables will not line up.
* **`ro.opengles.version = 0x20000`** — ES 2.0 only. Do not claim 3.x.
* Unrelated hardware may simply not be wired up on a bring-up port (network, camera, sensors,
  audio). That does not affect the GPU work but it changes which apps are usable.

---

# Part F — never-do list

1. **Never rebuild the renderer binary casually.** `$PORT/tools/glrenderd/build.sh` runs
   `emugen` and **regenerates the GLESv1/GLESv2/renderControl codec tables**. A rebuilt renderer
   can end up with decode tables that no longer match the guest encoder libraries already
   deployed in `/system/lib` — the panel comes up dim and garbled. Either keep the known-good
   binary, or rebuild the guest `*_enc.so` libraries from the same tree at the same time and
   deploy them together.
2. **Never add a member to `HostConnection`, and never move `IOStream`'s members.**
   `alloc()`/`flush()` are inline in a header, so every already-built guest library has them
   inlined with hard-coded member offsets. Adding one member shifts them and crashes the
   framework on the next GL call. Put extra state in a file-static in the `.cpp` — that is
   exactly what A1 does.
3. **Never free the connection objects to "recover"** from a dead renderer. Reconnect the socket
   in place (A3).
4. **Never let two components present to `fb0`.**
5. **Keep a copy of every binary you replace**, on the device and off it, with its checksum, and
   a one-command way to put it back. That has saved this bring-up more than once.

---

# Part G — how to tell it is working

From the kernel log (there is no `logcat`):

* `FRAMING LOST = 0`, `RESYNC = 0` — stream intact (A1).
* One renderer client per GL-using process, distinct pids (A1).
* The two socket-limit lines at startup (A2).
* Renderer reporting sane per-frame cost, e.g.
  `glrenderd: 34.9 fps shown, per frame readback 9.5ms copy 6.3ms flip 7.4ms`.
* `dumpsys input` → `DispatchFrozen: 0`.
* Screen off stays off; screen timeout ramps to 0; power restores it (Part B).

Suggested order on a new device: get a plain framework UI up first → bring the renderer up and
confirm `FRAMING LOST = 0` with a single presenter → apply A1 (the artifact fix) and re-verify →
A2/A6 for performance → A3/A4/A5, Part B and Part C for robustness.

---

# Part H — building the boot image and flashing it (complete)

Some fixes ship as libraries you push. A few ship **inside the boot image**, because they live in
the ramdisk — and those cannot be delivered with `adb push` at all. This is the whole procedure.

## H1. What ships where

| fix | ships as | to apply |
|---|---|---|
| A1 fork safety (the artifact fix), A3 bounded reply + socket + `SIGPIPE` | `/system/lib/libOpenglSystemCommon.so` | push + reboot |
| A4 bounded `glGetError` loops | `/system/lib/libgui.so` | push + reboot |
| C2 frozen input dispatch | `/system/lib/libinputservice.so` | push + reboot |
| B8 brightness (`lights` HAL) | `/system/lib/hw/lights.<device>.so` | push + reboot |
| C1 touch post-probe | `init.<device>.rc` | **boot image** |
| B1–B7 sleep / panel power | `init.<device>.rc` + a script in `/sbin/` | **boot image** |
| D crash-evidence keeper | `/system/bin/` or `/sbin/` | boot image, or push |

The ramdisk is assembled from `PRODUCT_COPY_FILES` entries that have a **`root/` prefix**. On the
reference device that is:

```
device/<vendor>/<device>/init.rc:root/init.rc
device/<vendor>/<device>/init.<device>.rc:root/init.<device>.rc
device/<vendor>/<device>/init.<device>.usb.rc:root/init.<device>.usb.rc
device/<vendor>/<device>/ueventd.<device>.rc:root/ueventd.<device>.rc
device/<vendor>/<device>/fstab.<device>:root/fstab.<device>
device/<vendor>/<device>/glrenderd.sh:root/sbin/glrenderd.sh
device/<vendor>/<device>/displaytune.sh:root/sbin/displaytune.sh
device/<vendor>/<device>/usbudc.sh:root/sbin/usbudc.sh
```

Anything under `root/` needs `make bootimage` and a flash. If you edit one of those files and
push it to `/system`, nothing changes — that mistake costs an hour.

## H2. The build environment — this is the part that bites

KitKat's build system expects **GNU make 3.81** and a **JDK 6**. A modern make or JDK 8+ fails in
obscure ways that look like source errors. Get those first:

```sh
export JAVA_HOME=<path to a jdk6>
export ANDROID_JAVA_HOME="$JAVA_HOME"
export PATH=<path to make-3.81>/bin:$JAVA_HOME/bin:$PATH
export USE_CCACHE=1

cd $AOSP
source build/envsetup.sh
lunch full_<device>-eng          # target name from AndroidProducts.mk
```

## H3. The kernel

The boot image needs a kernel at the path named in `BoardConfig.mk`, with geometry that matches
the device — get any of these wrong and the image will not boot:

```make
TARGET_PREBUILT_KERNEL := device/<vendor>/<device>/kernel
BOARD_KERNEL_BASE      := 0x00000000
BOARD_KERNEL_PAGESIZE  := 4096
BOARD_KERNEL_IMAGE_NAME := Image.gz-dtb
BOARD_KERNEL_CMDLINE   := ... androidboot.hardware=<device>
BOARD_BOOTIMAGE_PARTITION_SIZE := 67108864
```

The reference build used the **stock kernel dumped from the device** rather than a rebuilt one.
Read the boot partition, unpack it with your usual tool (`unpackbootimg`, `mkbootimg`, or a small
script), and put the kernel at that path:

```sh
adb shell "dd if=/dev/block/bootdevice/by-name/boot of=/data/local/tmp/boot-stock.img"
adb pull /data/local/tmp/boot-stock.img
# unpack, then copy the extracted kernel to device/<vendor>/<device>/kernel
```

## H4. Build

```sh
make -j"$(nproc)" bootimage
ls -l out/target/product/<device>/boot.img
```

## H5. Verify the ramdisk *before* flashing

This step has caught real mistakes — a new file silently not installed, or a file you deleted
still present from an earlier build:

```sh
R=out/target/product/<device>/root
grep -n 'displaytune\|post_probe_start\|glrenderd' "$R/init.<device>.rc"
ls -l "$R/sbin/"
```

Note that `make` does **not** remove files you deleted from `out/`; delete them by hand, or a
ramdisk rebuild will keep shipping them.

## H6. Flash

```sh
adb reboot bootloader
fastboot devices
fastboot flash boot <path>/boot.img
fastboot reboot
```

Keep the previous image around — the revert is the same command with the old file:

```sh
fastboot flash boot <previous-known-good>.img
```

## H7. Adjacent: `/system` changes

Everything not in the ramdisk belongs in `/system`, and pushing a file is usually faster than
reflashing:

```sh
adb root && adb remount
adb push <file> /system/<path>
adb shell "chmod 644 <file>; sync"
adb reboot
```

Single files this way are fine (that is how every library fix here was deployed). If you are
changing many, build and flash the system image instead:

```sh
make -j"$(nproc)" systemimage
fastboot flash system out/target/product/<device>/system.img
```

Remember the two rules from Part F while you are doing all this: keep a copy of every image and
binary you replace, and do not rebuild the renderer on its own.
