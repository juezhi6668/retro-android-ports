#!/bin/bash
# For each of the benchmark's bundled libraries, list what it needs at link time
# and say whether the device has it. This is the definitive answer to "are
# libraries missing?" - an app's own .so come from the APK, but everything they
# link against must come from the platform.
cd "/mnt/c/Users/Admin/Desktop/sony xz1/flash/logs/gfxbench-libs" || exit 1
SYS=${SYS:-system-lib.txt}
VEND=vendor-lib.txt

echo "system libs known: $(wc -l < "$SYS")   vendor libs known: $(wc -l < "$VEND" 2>/dev/null || echo 0)"
echo

missing_total=0
for so in libs/*.so; do
    echo "===== ${so##*/}"
    needs=$(readelf -d "$so" 2>/dev/null | awk '/NEEDED/{print $NF}' | tr -d '[]')
    if [ -z "$needs" ]; then
        echo "   (no dynamic dependencies - static?)"
        continue
    fi
    for need in $needs; do
        if grep -qx "$need" "$SYS"; then
            st="ok  (/system/lib)"
        elif grep -qx "$need" "$VEND" 2>/dev/null; then
            st="ok  (/vendor/lib)"
        elif [ -e "libs/$need" ]; then
            st="ok  (bundled in the APK)"
        else
            st="*** MISSING ***"
            missing_total=$((missing_total + 1))
        fi
        printf '   %-34s %s\n' "$need" "$st"
    done
    echo
done

echo "############################################################"
echo "TOTAL MISSING DEPENDENCIES: $missing_total"
echo
echo "### libraries the app may dlopen at runtime (not DT_NEEDED)"
for n in libGLESv3.so libGLESv2.so libEGL.so libhwui.so libsqlite.so libOpenSLES.so libjnigraphics.so libc++_shared.so; do
    if grep -qx "$n" "$SYS"; then echo "   present  $n"; else echo "   ABSENT   $n"; fi
done
