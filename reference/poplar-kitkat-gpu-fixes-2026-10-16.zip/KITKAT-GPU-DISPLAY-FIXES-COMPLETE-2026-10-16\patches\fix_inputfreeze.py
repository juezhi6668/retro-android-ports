#!/usr/bin/env python3
"""
Input dispatch must not be able to stay frozen forever.

WindowManagerService freezes input dispatch around window transitions
(InputMonitor.freezeInputDispatchingLw -> InputManagerService ->
InputDispatcher::setInputDispatchMode(enabled, frozen)). Normally it thaws a few
hundred ms later. If the transition never completes - easy when the app that was
transitioning just died - the freeze is permanent, and nothing recovers it:

  * InputReader keeps delivering events (the touchscreen is fine),
  * they pile up in mInboundQueue (observed: length=80),
  * the dispatcher thread sleeps in epoll with an infinite timeout, because the
    frozen branch of dispatchOnceInnerLocked() returns WITHOUT setting
    *nextWakeupTime,
  * so the UI animates (surfaceflinger and WMS are alive and drawing) while
    nothing at all accepts a touch.

Observed live as: DispatchEnabled: 1 / DispatchFrozen: 1, InboundQueue length=80,
RecentQueue full of clearpad MotionEvents aged ~48 s, and `input keyevent 3`
hanging until killed.

Fix: while frozen, arm a wakeup at a deadline and lift the freeze ourselves once
it passes, logging loudly (to stderr and /data/system/dispatch-thaw.log, since
logcat is blind on this kernel). Legitimate freezes are the length of a window
animation, so 10 s is far above anything real.
"""
import io
import os
import sys

D = "/root/aosp/frameworks/base/services/input"


def rd(p):
    with io.open(p, "r", encoding="utf-8", errors="surrogateescape") as f:
        return f.read()


def wr(p, s):
    with io.open(p, "w", encoding="utf-8", errors="surrogateescape") as f:
        f.write(s)


def sub1(s, old, new, what):
    if s.count(old) != 1:
        sys.exit("FAIL %s: %d matches" % (what, s.count(old)))
    return s.replace(old, new, 1)


# ---------------- header: track when the freeze started ----------------
p = os.path.join(D, "InputDispatcher.h")
s = rd(p)
s = sub1(s,
    "    bool mDispatchEnabled;\n    bool mDispatchFrozen;",
    "    bool mDispatchEnabled;\n    bool mDispatchFrozen;\n"
    "    // POPLAR: monotonic time the current freeze started, 0 when not frozen. Used to\n"
    "    // lift a freeze that is never lifted by the caller (see dispatchOnceInnerLocked).\n"
    "    nsecs_t mDispatchFrozenTime;",
    "InputDispatcher.h member")
wr(p, s)

# ---------------- implementation ----------------
p = os.path.join(D, "InputDispatcher.cpp")
s = rd(p)

s = sub1(s,
    "    mDispatchEnabled(false), mDispatchFrozen(false), mInputFilterEnabled(false),",
    "    mDispatchEnabled(false), mDispatchFrozen(false), mDispatchFrozenTime(0),\n"
    "    mInputFilterEnabled(false),",
    "ctor init")

CONST = """// POPLAR: how long a frozen dispatch may last before we lift it ourselves.
// WindowManagerService freezes dispatch around window transitions; a real
// transition is a few hundred milliseconds. If the transition never completes
// (e.g. the app that was transitioning died), the frozen branch below returns
// without setting nextWakeupTime, so the dispatcher sleeps forever and the
// device keeps drawing a UI that accepts no touch at all.
#define kMaxDispatchFreezeNanos (10 * 1000000000LL)

"""

s = sub1(s,
    "void InputDispatcher::dispatchOnceInnerLocked(nsecs_t* nextWakeupTime) {",
    CONST + "void InputDispatcher::dispatchOnceInnerLocked(nsecs_t* nextWakeupTime) {",
    "const placement")

s = sub1(s,
    """    // If dispatching is frozen, do not process timeouts or try to deliver any new events.
    if (mDispatchFrozen) {
#if DEBUG_FOCUS
        ALOGD("Dispatch frozen.  Waiting some more.");
#endif
        return;
    }""",
    """    // If dispatching is frozen, do not process timeouts or try to deliver any new events.
    if (mDispatchFrozen) {
        if (mDispatchFrozenTime
                && currentTime - mDispatchFrozenTime > kMaxDispatchFreezeNanos) {
            // POPLAR: whoever froze us is not coming back. Lift it, or input stays
            // dead for the rest of the boot (the UI keeps animating, touches queue
            // up in mInboundQueue and go nowhere).
            nsecs_t frozenForMs = (currentTime - mDispatchFrozenTime) / 1000000;
            ALOGE("Dispatch has been frozen for %lld ms - forcing it back on, "
                  "input would otherwise be dead for good",
                  (long long)frozenForMs);
            FILE* fp = fopen("/data/system/dispatch-thaw.log", "a");
            if (fp) {
                fprintf(fp, "frozen for %lld ms at uptime-ish %lld ms, forcing thaw\\n",
                        (long long)frozenForMs, (long long)(systemTime(SYSTEM_TIME_BOOTTIME) / 1000000));
                fclose(fp);
            }
            mDispatchFrozen = false;
            mDispatchFrozenTime = 0;
            resetANRTimeoutsLocked();
            mLooper->wake();
            // fall through and dispatch normally
        } else {
#if DEBUG_FOCUS
            ALOGD("Dispatch frozen.  Waiting some more.");
#endif
            // Wake up when the deadline passes, otherwise this branch parks the
            // dispatcher on an infinite poll timeout and it is never re-checked.
            if (mDispatchFrozenTime) {
                nsecs_t deadline = mDispatchFrozenTime + kMaxDispatchFreezeNanos;
                if (deadline < *nextWakeupTime) {
                    *nextWakeupTime = deadline;
                }
            }
            return;
        }
    }""",
    "frozen branch")

s = sub1(s,
    """            mDispatchEnabled = enabled;
            mDispatchFrozen = frozen;
            changed = true;""",
    """            mDispatchEnabled = enabled;
            mDispatchFrozen = frozen;
            mDispatchFrozenTime = frozen ? now() : 0;
            changed = true;""",
    "setInputDispatchMode")

wr(p, s)
print("OK - InputDispatcher patched")
