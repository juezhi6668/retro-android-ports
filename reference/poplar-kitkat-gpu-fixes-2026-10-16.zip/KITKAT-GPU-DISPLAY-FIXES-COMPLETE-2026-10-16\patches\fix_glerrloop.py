#!/usr/bin/env python3
"""
Bound the unbounded glGetError() clearing loops in libgui's GLConsumer.

On this port glGetError() is a synchronous round-trip to glrenderd (a socket
send plus a blocking recv). GLConsumer::bindTextureImageLocked() and
bindUnslottedBufferLocked() run "while (glGetError() != GL_NO_ERROR)" to clear
stale errors. Against a remote renderer that is an unbounded loop of blocking
round-trips - and bindTextureImageLocked() runs on the *compositor* thread for
every buffer a SurfaceTexture-backed app (i.e. every game) hands over.

Observed: the crash ANR's surfaceflinger thread was in
    glGetError_enc <- GL2Encoder::s_glGetError <- glGetError
    <- GLConsumer::bindTextureImageLocked()+56 <- ... <- SurfaceFlinger::run()
blocked in recv(). Bounding the loops means the compositor can never be parked
there indefinitely; it does at most a handful of round-trips and moves on.
"""
import io
import sys

p = "/root/aosp/frameworks/native/libs/gui/GLConsumer.cpp"
with io.open(p, "r", encoding="utf-8", errors="surrogateescape") as f:
    s = f.read()


def sub1(s, old, new, what):
    if s.count(old) != 1:
        sys.exit("FAIL %s: %d matches" % (what, s.count(old)))
    return s.replace(old, new, 1)


# 1. bindTextureImageLocked() - the loop the crash was parked in
s = sub1(s,
    """    GLint error;
    while ((error = glGetError()) != GL_NO_ERROR) {
        ST_LOGW("bindTextureImage: clearing GL error: %#04x", error);
    }""",
    """    // POPLAR: glGetError() is a synchronous round-trip to the renderer here, so
    // an unbounded "clear the errors" loop spins for as long as the renderer is
    // busy - on the compositor thread, which freezes the whole display. Bound it;
    // clearing a handful of stale errors is all this is for.
    GLint error;
    for (int i = 0; i < 8 && (error = glGetError()) != GL_NO_ERROR; i++) {
        ST_LOGW("bindTextureImage: clearing GL error: %#04x", error);
    }""",
    "bindTextureImageLocked clearing loop")

# 2. bindUnslottedBufferLocked() - also loops until NO_ERROR, no early return
s = sub1(s,
    """    GLint error;
    status_t err = OK;
    while ((error = glGetError()) != GL_NO_ERROR) {
        ST_LOGE("bindUnslottedBuffer: error binding external texture image %p "
                "(slot %d): %#04x", image, mCurrentTexture, error);
        err = UNKNOWN_ERROR;
    }""",
    """    // POPLAR: bounded for the same reason as the loop in bindTextureImageLocked
    GLint error;
    status_t err = OK;
    for (int i = 0; i < 8 && (error = glGetError()) != GL_NO_ERROR; i++) {
        ST_LOGE("bindUnslottedBuffer: error binding external texture image %p "
                "(slot %d): %#04x", image, mCurrentTexture, error);
        err = UNKNOWN_ERROR;
    }""",
    "bindUnslottedBufferLocked clearing loop")

with io.open(p, "w", encoding="utf-8", errors="surrogateescape") as f:
    f.write(s)
print("OK - libgui patched")
