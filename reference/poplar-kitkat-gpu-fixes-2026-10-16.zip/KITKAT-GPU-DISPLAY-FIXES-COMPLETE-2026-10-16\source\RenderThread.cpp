/*
* Copyright (C) 2011 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
#include "RenderThread.h"
#include "RenderControl.h"
#include "ThreadInfo.h"
#include "ReadBuffer.h"
#include "TimeUtils.h"
#include "GLDispatch.h"
#include "GL2Dispatch.h"
#include "EGLDispatch.h"
#include "FrameBuffer.h"

#include <string.h>
#include <stdlib.h>

// start small and let ReadBuffer::getData() grow it (bounded at 32 MiB);
// several clients each hold one of these
#define STREAM_BUFFER_SIZE 8*1024*1024

// No legal single message here comes close to this (the biggest are a full
// 1080x1920 RGBA colour-buffer push at 8.3 MB and texture uploads at ~12 MB).
#define GLR_MAX_MSG (24u<<20)

RenderThread::RenderThread() :
    osUtils::Thread(),
    m_stream(NULL),
    m_finished(false)
{
}

RenderThread::~RenderThread()
{
    delete m_stream;
}

RenderThread *RenderThread::create(IOStream *p_stream)
{
    RenderThread *rt = new RenderThread();
    if (!rt) {
        return NULL;
    }

    rt->m_stream = p_stream;

    return rt;
}

/* --- glr diag ------------------------------------------------------------ */
// Ring of the last commands seen on this connection. Recorded per command, not
// per decoder call, so the entry immediately before a framing loss is the one
// whose declared length was wrong.
#define GLR_RING 32
typedef struct { int op; unsigned int plen; int len; unsigned int f[8]; } GlrEntry;
static __thread GlrEntry g_glr_ring[GLR_RING];
static __thread int g_glr_ringn = 0;

static inline unsigned int glr_rd32(const unsigned char* p) {
    unsigned int v = 0;
    memcpy(&v, p, 4);
    return v;
}

static void glr_record(int op, unsigned int plen, int len,
                       const unsigned char* head, size_t avail) {
    int idx = g_glr_ringn % GLR_RING;
    g_glr_ring[idx].op = op;
    g_glr_ring[idx].plen = plen;
    g_glr_ring[idx].len = len;
    for (int i = 0; i < 8; i++)
        g_glr_ring[idx].f[i] = (avail >= (size_t)(12 + 4*i)) ? glr_rd32(head + 8 + 4*i) : 0;
    g_glr_ringn++;
}

// The three opcode spaces are dense and disjoint (checked against the generated
// tables): GLESv1 1024..1315, GLESv2 2048..2256, renderControl 10000..10025.
static inline bool glr_known_op(int op) {
    return (op >= 1024  && op <= 1315) ||
           (op >= 2048  && op <= 2256) ||
           (op >= 10000 && op <= 10025);
}

static void glr_dump_ring(int pid, const unsigned char* head, size_t avail) {
    int m = avail < 64 ? (int)avail : 64;
    fprintf(stderr, "[glr-rt] FRAMING LOST pid=%d avail=%u head:", pid, (unsigned)avail);
    for (int i = 0; i < m; i++) fprintf(stderr, " %02x", head[i]);
    fprintf(stderr, "\n");
    // last 8 commands, with the raw header words (cb x y w h fmt type size)
    for (int i = 8; i > 0; i--) {
        int k = g_glr_ringn - i;
        if (k < 0) continue;
        const GlrEntry* e = &g_glr_ring[k % GLR_RING];
        fprintf(stderr, "[glr-rt]   last[%d] op=%d plen=%u consumed=%d"
                        " cb=%u x=%u y=%u w=%u h=%u fmt=0x%x type=0x%x size=%u\n",
                -i, e->op, e->plen, e->len,
                e->f[0], e->f[1], e->f[2], e->f[3], e->f[4], e->f[5], e->f[6], e->f[7]);
    }
    fflush(stderr);
}

// Find the next real message boundary. Candidate offsets are rare (the opcode
// has to be one of ~530 values), so we can walk forward from a candidate and
// require a run of well-formed messages rather than trusting a single match.
// Note: since the guest fork-safety fix in HostConnection this path no longer
// triggers in practice - it is a safety net.
#define GLR_RESYNC_RUN 2
static size_t glr_resync(const unsigned char* buf, size_t avail) {
    for (size_t off = 4; off + 8 <= avail; off += 4) {
        unsigned int op = glr_rd32(buf + off);
        if (!glr_known_op((int)op)) continue;
        unsigned int plen = glr_rd32(buf + off + 4);
        if (plen < 8 || plen > GLR_MAX_MSG) continue;

        size_t p = off;
        int run = 0;
        bool ok = true;
        while (run < GLR_RESYNC_RUN && p + 8 <= avail) {
            unsigned int o = glr_rd32(buf + p);
            unsigned int l = glr_rd32(buf + p + 4);
            if (!glr_known_op((int)o) || l < 8 || l > GLR_MAX_MSG) { ok = false; break; }
            if (p + l > avail) break;      // ran out of buffered data mid-run
            p += l;
            run++;
        }
        // accept a long run, or whatever we could verify if the buffer ends
        if (ok && run >= ((avail - off) > (size_t)GLR_MAX_MSG ? GLR_RESYNC_RUN : 2))
            return off;
    }
    return 0;
}

/* --- raw stream history -------------------------------------------------- */
// A rolling copy of everything this connection sent, so the first framing loss
// can be written out with its cause intact. 12 MiB covers the largest message
// (8.3 MB) plus the ones before it.
#define GLR_HIST (12u<<20)
static __thread unsigned char* g_hist;
static __thread size_t g_histPos;
static __thread size_t g_histTotal;
static __thread bool g_histSaved;

static void glr_hist_append(const unsigned char* p, size_t n) {
    if (!g_hist) {
        g_hist = (unsigned char*)malloc(GLR_HIST);
        if (!g_hist) return;
    }
    while (n) {
        size_t chunk = GLR_HIST - g_histPos;
        if (chunk > n) chunk = n;
        memcpy(g_hist + g_histPos, p, chunk);
        g_histPos = (g_histPos + chunk) % GLR_HIST;
        g_histTotal += chunk;
        p += chunk;
        n -= chunk;
    }
}

static void glr_hist_save(int pid) {
    if (g_histSaved || !g_hist || g_histTotal == 0) return;
    g_histSaved = true;
    char path[64];
    snprintf(path, sizeof(path), "/dev/glr-stream-%d.bin", pid);
    FILE* f = fopen(path, "wb");
    if (!f) {
        fprintf(stderr, "[glr-rt] could not open %s for stream history\n", path);
        fflush(stderr);
        return;
    }
    size_t start = (g_histTotal >= GLR_HIST) ? g_histPos : 0;
    size_t len   = (g_histTotal >= GLR_HIST) ? GLR_HIST : g_histPos;
    fwrite(g_hist + start, 1, GLR_HIST - start, f);
    if (start) fwrite(g_hist, 1, start, f);
    fclose(f);
    fprintf(stderr, "[glr-rt] wrote %u bytes of stream history to %s\n",
            (unsigned)len, path);
    fflush(stderr);
}

int RenderThread::Main()
{
    RenderThreadInfo tInfo;

    //
    // initialize decoders
    //
    tInfo.m_glDec.initGL( gl_dispatch_get_proc_func, NULL );
    tInfo.m_gl2Dec.initGL( gl2_dispatch_get_proc_func, NULL );
    initRenderControlContext( &m_rcDec );

    ReadBuffer readBuf(m_stream, STREAM_BUFFER_SIZE);

    int stats_totalBytes = 0;
    long long stats_t0 = GetCurrentTimeMS();

    //
    // open dump file if RENDER_DUMP_DIR is defined
    //
    const char *dump_dir = getenv("RENDERER_DUMP_DIR");
    FILE *dumpFP = NULL;
    if (dump_dir) {
        size_t bsize = strlen(dump_dir) + 32;
        char *fname = new char[bsize];
        snprintf(fname,bsize,"%s/stream_%p", dump_dir, this);
        dumpFP = fopen(fname, "wb");
        if (!dumpFP) {
            fprintf(stderr,"Warning: stream dump failed to open file %s\n",fname);
        }
        delete [] fname;
    }

    const int peerPid = m_stream->peerPid();
    fprintf(stderr, "[glr-rt] client pid=%d\n", peerPid);
    fflush(stderr);

    bool desynced = false;

    while (1) {

        int stat = readBuf.getData();
        if (stat <= 0) {
            // client gone, or its stream is unparseable. Tear the socket down
            // so a guest blocked in send() gets EPIPE and can recover.
            // Logged because a guest that gave up waiting for a reply (see
            // SocketStream.cpp in the guest) shows up here as a drop followed by
            // a fresh "client pid=" line - which is how we tell "the renderer
            // wedged" from "the app crashed".
            fprintf(stderr, "[glr-rt] client pid=%d dropped (getData=%d)\n", peerPid, stat);
            fflush(stderr);
            m_stream->shutdownStream();
            break;
        }

        //
        // log received bandwidth statistics
        //
        stats_totalBytes += readBuf.validData();
        long long dt = GetCurrentTimeMS() - stats_t0;
        if (dt > 1000) {
            float dts = (float)dt / 1000.0f;
            //printf("Used Bandwidth %5.3f MB/s\n", ((float)stats_totalBytes / dts) / (1024.0f*1024.0f));
            stats_totalBytes = 0;
            stats_t0 = GetCurrentTimeMS();
        }

        //
        // dump stream to file if needed
        //
        if (dumpFP) {
            int skip = readBuf.validData() - stat;
            fwrite(readBuf.buf()+skip, 1, readBuf.validData()-skip, dumpFP);
            fflush(dumpFP);
        }

        {
            size_t vd = readBuf.validData();
            if (vd >= (size_t)stat)
                glr_hist_append(readBuf.buf() + (vd - stat), (size_t)stat);
        }

        bool progress;
        do {
            progress = false;

            size_t avail = readBuf.validData();
            if (avail < 8) break;

            unsigned char* head = readBuf.buf();
            int op = (int)glr_rd32(head);
            unsigned int plen = glr_rd32(head + 4);

            // rcUpdateColorBuffer's header is 40 bytes: opcode, packetLen, then
            // cb x y w h fmt type size_pixels. The guest's headers all check out
            // (packetLen == 40 + w*h*bpp exactly), so framing by packetLen is
            // right *provided the payload actually arrives*. When it does not,
            // the byte at offset 40 is the next message's opcode - log that, and
            // do NOT second-guess the length.
            if (op == 10024 && avail >= 48) {
                unsigned int sizeFld  = glr_rd32(head + 36);
                unsigned int nextOp   = glr_rd32(head + 40);
                unsigned int nextPlen = glr_rd32(head + 44);
                bool nextLooksReal = glr_known_op((int)nextOp) &&
                                     nextPlen >= 8 && nextPlen <= GLR_MAX_MSG;
                if (nextLooksReal && avail >= (size_t)(48 + nextPlen + 8)) {
                    // require the command after that one to look real too - two
                    // hits in a row is not something pixel data produces
                    if (!glr_known_op((int)glr_rd32(head + 40 + nextPlen)))
                        nextLooksReal = false;
                }
                if (nextLooksReal && plen > 40) {
                    // The 40-byte header is followed directly by the next message:
                    // this update's payload never made it onto the wire (the peer's
                    // write failed and the error was swallowed). Skip exactly the
                    // header so the stream stays framed, instead of consuming
                    // packetLen and eating every message behind it.
                    fprintf(stderr, "[glr-rt] NOPAYLOAD pid=%d op=10024 plen=%u size_field=%u next_op=%u"
                                    " -> payload of %u bytes never arrived, skipping header\n",
                            peerPid, plen, sizeFld, nextOp, plen - 40);
                    fflush(stderr);
                    readBuf.consume(40);
                    progress = true;
                    continue;
                }
            }

            if (!glr_known_op(op) || plen < 8 || plen > GLR_MAX_MSG) {
                // Nothing can consume this. The stream lost framing: some
                // earlier message's declared length did not match what was
                // written, so payload bytes now sit where a header should be.
                // Report it once, then skip to the next usable boundary. If
                // there is not one yet, wait for more data - the mis-framed
                // message is still draining, and ReadBuffer's cap is the
                // backstop if it never recovers.
                if (!desynced) {
                    desynced = true;
                    glr_dump_ring(peerPid, head, avail);
                    glr_hist_save(peerPid);
                }
                size_t off = glr_resync(head, avail);
                if (off > 0) {
                    fprintf(stderr, "[glr-rt] RESYNC pid=%d skipped=%u resuming at op=%u\n",
                            peerPid, (unsigned)off, glr_rd32(head + off));
                    fflush(stderr);
                    readBuf.consume(off);
                    desynced = false;
                    progress = true;
                    continue;
                }
                break;   // wait for more data
            }
            desynced = false;

            // Hand a decoder at most one declared message. The decoders trust
            // packetLen and advance by it, so feeding them the whole buffer
            // lets a single wrong length eat every command after it.
            size_t lim = (plen <= avail) ? (size_t)plen : avail;

            size_t last = tInfo.m_glDec.decode(head, lim, m_stream);
            if (last > 0) {
                glr_record(op, plen, (int)last, head, avail);
                readBuf.consume(last);
                progress = true;
                continue;
            }

            last = tInfo.m_gl2Dec.decode(head, lim, m_stream);
            if (last > 0) {
                glr_record(op, plen, (int)last, head, avail);
                readBuf.consume(last);
                progress = true;
                continue;
            }

            last = m_rcDec.decode(head, lim, m_stream);
            if (last > 0) {
                glr_record(op, plen, (int)last, head, avail);
                readBuf.consume(last);
                progress = true;
                continue;
            }

            // Known opcode, but no decoder took it, or the whole message has
            // not arrived yet. Wait for more data.
            break;

        } while( progress );

    }

    if (dumpFP) {
        fclose(dumpFP);
    }

    //
    // Release references to the current thread's context/surfaces if any
    //
    FrameBuffer::getFB()->bindContext(0, 0, 0);
    if (tInfo.currContext || tInfo.currDrawSurf || tInfo.currReadSurf) {
        fprintf(stderr, "ERROR: RenderThread exiting with current context/surfaces\n");
    }

    //
    // flag that this thread has finished execution
    //
    m_finished = true;

    return 0;
}
